class DptoInformatica{


    constructor(){

    }

    addAula(){

    }

}